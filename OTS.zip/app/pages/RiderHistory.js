import React from "react";
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Entypo from "@expo/vector-icons/Entypo";
import FontAwesome5 from "@expo/vector-icons/FontAwesome5";

export default function RiderHistory({ navigation }) {
  const rides = [
    {
      id: 1,
      location: "G-11, Islamabad, Pakistan",
      place: "Hill View Hotel",
      price: "Rs 200",
      date: "Jan 8, 2022 - 3:33",
    },
    {
      id: 2,
      location: "G-11, Islamabad, Pakistan",
      place: "Hill View Hotel",
      price: "Rs 180",
      date: "Jan 8, 2022 - 2:33",
    },
  ];

  return (
    <ScrollView style={{ height: "100%" }}>
      <View style={{ flex: 1, backgroundColor: "#538cc6", padding: 12 }}>
        {/* Header */}
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 20 }}>
          <Ionicons name="arrow-back" size={24} color="#2c5aa0" />
          <Text style={{ fontSize: 30, fontWeight: "600", marginLeft: 100 }}>
            Rider History
          </Text>
        </View>

        {/* Ride History List */}
        {rides.map((ride) => (
          <View
            key={ride.id}
            style={{
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#181515ff",
            }}
          >
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontSize: 16, color: "#2c5aa0" }}>
                <Entypo name="location-pin" size={24} color="#2c5aa0" /> {ride.location}
              </Text>
              <Text style={{ fontSize: 16, fontWeight: "600", color: "#2c5aa0" }}>
                {ride.price}
              </Text>
            </View>
            <Text
              style={{
                fontSize: 14,
                color: "#0f0e0eff",
                marginTop: 10,
                marginLeft: 10,
              }}
            >
              <FontAwesome5 name="search-location" size={20} color="#2c5aa0" /> {ride.place}
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: "#0e0b0bff",
                marginTop: 10,
                marginLeft: 10,
              }}
            >
              {ride.date}
            </Text>
          </View>
        ))}

        {/* Button at Bottom */}
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate("RiderEarning")}
        >
          <Text style={styles.buttonText}>Go to RiderEarning</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: "#FFFFFF",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: { color: "#000000", fontSize: 16, fontWeight: "600" },
});
