// import { createNativeStackNavigator } from "@react-navigation/native-stack";
// import HomeRider from "../pages/HomeRider";

// const Stack = createNativeStackNavigator();

// export default function HomeStack() {
//   return (
//     <Stack.Navigator initialRouteName="HomeRider">
    
//     <Stack.Screen name="HomeRider" component={HomeRider} />
   

//     </Stack.Navigator>
//   );
// }
