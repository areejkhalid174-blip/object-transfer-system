// import { createNativeStackNavigator } from "@react-navigation/native-stack";
// import Homer from "../pages/HomeRider";

// const Stack = createNativeStackNavigator();

// export default function ProfileStack() {
//   return (
//     <Stack.Navigator initialRouteName="Homer">
    
//     <Stack.Screen name="Homer" component={Homer} />
   

//     </Stack.Navigator>
//   );
// }
